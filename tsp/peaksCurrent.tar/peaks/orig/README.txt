
tableA and tableB have the same format:

 indexNumber xPPM yPPM peakHeight

For example, from table A:

    1    8.278  113.008 +1.305967e+02
    2    7.456  112.778 +3.378418e+02
    4    8.007  112.255 +1.161067e+02
    5    7.544  112.214 +5.520787e+02

and from table B:

    2    8.274  113.264 +1.645234e+02
    4    7.455  112.730 +3.797111e+02
    7    7.993  112.293 +1.379858e+02
    9    7.495  112.115 +7.863762e+02

etc.

The tables will have different numbers of peaks. The length of our "path"
will be whichever size is larger.

The index number will be unique, but not consecutive, and greater than zero.

xPPM and yPPM are the peak locations in units of "ppm". They can be negative
or positive. By convention, in a 2D plot, X-Axis ppm values increase from
right to left, and Y-Axis ppm values increase from top to bottom.

The X-Axis and Y-Axis ppm values will usually have different ranges.
In the example, the X-Axis goes from about 8.4ppm to 6.9ppm, and the
Y-Axis from 114.1ppm to 104.3ppm.

In this example, the peak heights go from 0 to 1000.0.

Since the peak positions and heights all have different ranges, we can
use scaling factors to combine them into a single "distance". To begin with,
we won't weight the peak height heavily.

The "distance" between a peak from table A and a peak from table B can be
calcultated this way:

   sqrt( cX*(peakA_xPPM - peakB_xPPM)^2 + 
         cY*(peakA_yPPM - peakB_yPPM)^2 + 
         cHi*((peakA_height - peakB_height))

where cX cY and cHi are scaling factors.

The graphic of the spectra is "spectra.gif". The pixel coords
of the four corners are:

    8  690 sw 8.356ppm 114.069ppm
 1088  692 se 6.937ppm 114.069ppm
   10   10 nw 8.356ppm 104.319ppm
 1088   10 ne 6.937ppm 104.319ppm

you can use these values to convert a xPPM,yPPM coord to an xPixel,xPixel coord.





